jQuery(document).ready(function ($) {
  $('.prp-status-select').on('change', function () {
    var selectElement = $(this);
    var requestId = selectElement.data('request-id');
    var newStatus = selectElement.val();
    var messageDiv = $('#prp-admin-message');

    // লোডিং স্টেট সেট করা
    messageDiv.html(
      '<span style="color: #FF0101;">স্ট্যাটাস আপডেট করা হচ্ছে...</span>'
    );

    $.ajax({
      url: prp_admin_ajax.ajax_url,
      type: 'POST',
      data: {
        action: 'prp_update_status',
        request_id: requestId,
        new_status: newStatus,
        prp_update_nonce: prp_admin_ajax.nonce,
      },
      success: function (response) {
        if (response.success) {
          messageDiv.html(
            '<span style="color: green;">স্ট্যাটাস সফলভাবে আপডেট করা হয়েছে!</span>'
          );
          // সফল হলে ড্রপডাউনের ক্লাস আপডেট করা
          selectElement
            .removeClass('status-pending status-complete status-cancel')
            .addClass('status-' + newStatus.toLowerCase());
        } else {
          messageDiv.html(
            '<span style="color: red;">ত্রুটি: ' + response.data + '</span>'
          );
        }
      },
      error: function () {
        messageDiv.html(
          '<span style="color: red;">সার্ভার ত্রুটি: স্ট্যাটাস আপডেট ব্যর্থ হয়েছে।</span>'
        );
      },
    });
  });
});
