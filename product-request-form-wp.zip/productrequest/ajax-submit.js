jQuery(document).ready(function ($) {
  $('#productRequestForm').on('submit', function (e) {
    e.preventDefault();

    var form = $(this);
    var formData = new FormData(form[0]);
    var messageDiv = $('#prp_message');

    // AJAX অ্যাকশন এবং ননস যোগ করা
    formData.append('action', 'prp_submit_request');
    formData.append(
      'product_request_field',
      form.find('input[name="product_request_field"]').val()
    );

    // মেসেজ প্রদর্শন: জমা দেওয়া হচ্ছে...
    messageDiv
      .html('জমা দেওয়া হচ্ছে...')
      .removeClass('success-msg error-msg')
      .addClass('loading-msg')
      .show();

    $.ajax({
      url: prp_ajax_object.ajax_url,
      type: 'POST',
      data: formData,
      contentType: false,
      processData: false,
      success: function (response) {
        if (response.success) {
          messageDiv
            .html(prp_ajax_object.success_message)
            .removeClass('loading-msg error-msg')
            .addClass('success-msg');
          form[0].reset();
          // ছবির আপলোড টেক্সট রিসেট করা
          form.find('.prp-upload-main-text').text('ছবি আপলোড করুন');
          form
            .find('.prp-upload-sub-text')
            .text('ড্র্যাগ এন্ড ড্রপ করুন অথবা ক্লিক করুন');
        } else {
          messageDiv
            .html(response.data || prp_ajax_object.error_message)
            .removeClass('loading-msg success-msg')
            .addClass('error-msg');
        }
      },
      error: function () {
        messageDiv
          .html(prp_ajax_object.error_message + ' (সার্ভার ত্রুটি)')
          .removeClass('loading-msg success-msg')
          .addClass('error-msg');
      },
    });
  });

  // ছবি আপলোড ইনপুট পরিবর্তন হলে লেবেলের টেক্সট পরিবর্তন করা
  $('#product_image').on('change', function () {
    var fileName = $(this).val().split('\\').pop();
    if (fileName) {
      $(this)
        .closest('.prp-upload-text-box')
        .find('.prp-upload-main-text')
        .text('Selected: ' + fileName);
      $(this)
        .closest('.prp-upload-text-box')
        .find('.prp-upload-sub-text')
        .text('Change file or submit');
    } else {
      $(this)
        .closest('.prp-upload-text-box')
        .find('.prp-upload-main-text')
        .text('ছবি আপলোড করুন');
      $(this)
        .closest('.prp-upload-text-box')
        .find('.prp-upload-sub-text')
        .text('ড্র্যাগ এন্ড ড্রপ করুন অথবা ক্লিক করুন');
    }
  });
});
