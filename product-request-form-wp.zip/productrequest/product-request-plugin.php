<?php
/**
 * Plugin Name:       Product Request 
 * Plugin URI:        https://example.com/
 * Description:       [product_request_form] A form to request quotes for specific parts with image uploads and admin viewing.
 * Version:           1.0.0
 * Author:            Rakib Hasan
 * Author URI:        codewithrakib.com
 * License:           GPL-2.0+
 * Text Domain:       product-request
 */

// নিরাপত্তা নিশ্চিত করতে সরাসরি অ্যাক্সেস ব্লক করা
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ১. প্লাগইন সক্রিয়করণ: ডেটাবেস টেবিল তৈরি
 */
function prp_install() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_requests';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        product_name tinytext NOT NULL,
        description text NOT NULL,
        additional_info text,
        vehicle_info text NOT NULL, /* মোবাইল নম্বর সংরক্ষণ করে */
        image_url text,
        status varchar(50) DEFAULT 'Pending' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}
register_activation_hook( __FILE__, 'prp_install' );

/**
 * ২. স্টাইল এবং স্ক্রিপ্ট এনকিউ করা
 */
function prp_enqueue_scripts() {
    // স্টাইল লোড করা
    wp_enqueue_style( 'prp-styles', plugins_url( 'style.css', __FILE__ ), array(), '1.0.0' );

    // ফ্রন্ট-এন্ড জাভাস্ক্রিপ্ট (AJAX) লোড করা
    wp_enqueue_script( 'prp-ajax-script', plugins_url( 'ajax-submit.js', __FILE__ ), array('jquery'), '1.0.0', true );

    // AJAX এর জন্য ভ্যারিয়েবল পাস করা
    wp_localize_script( 'prp-ajax-script', 'prp_ajax_object', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'product_request_nonce' ),
        'success_message' => 'আপনার অনুরোধ সফলভাবে জমা দেওয়া হয়েছে! আমরা দ্রুত আপনার সাথে যোগাযোগ করব।',
        'error_message' => 'ফর্ম জমা দিতে ব্যর্থ হয়েছে।',
    ) );
}
add_action( 'wp_enqueue_scripts', 'prp_enqueue_scripts' );


/**
 * ৩. ফর্ম ডিসপ্লে করার জন্য শর্টকোড ফাংশন
 */
function prp_form_html() {
    ob_start();
    ?>
    <div class="product-request-form-container">
        <div class="form-content">
            <form id="productRequestForm" class="space-y-6" enctype="multipart/form-data">
                <?php wp_nonce_field( 'product_request_nonce', 'product_request_field' ); ?>

                <div class="space-y-2">
                    <label class="prp-label">ছবি যোগ করুন</label>
                    <div id="image-upload-area" class="prp-file-upload-area">
                        <input type="file" name="product_image" id="product_image" accept="image/*" class="prp-file-input">
                        <div class="prp-upload-text-box">
                            <div class="prp-icon-bg">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="prp-icon">
                                    <rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect>
                                    <circle cx="9" cy="9" r="2"></circle>
                                    <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"></path>
                                </svg>
                            </div>
                            <div class="text-center">
                                <p class="prp-upload-main-text">ছবি আপলোড করুন</p>
                                <p class="prp-upload-sub-text">ড্র্যাগ এন্ড ড্রপ করুন অথবা ক্লিক করুন</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="space-y-2">
                    <label class="prp-label" for="partName">Product নাম*</label>
                    <input class="prp-input" id="partName" name="part_name" placeholder="Part Name" required="" type="text">
                </div>
                
                <div class="space-y-2">
                    <label class="prp-label" for="description">বিবরণ*</label>
                    <textarea class="prp-textarea" id="description" name="description" placeholder="Description of the part" required=""></textarea>
                </div>
                
                <div class="space-y-2">
                    <label class="prp-label" for="vehicleInfo">মোবাইল নম্বর *</label>
                    <input class="prp-input" id="vehicleInfo" name="vehicle_info" placeholder="আপনার নাম্বার" required="" type="text">
                </div>
                
                <button class="prp-submit-button" type="submit">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="prp-button-icon">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="17 8 12 3 7 8"></polyline>
                        <line x1="12" x2="12" y1="3" y2="15"></line>
                    </svg>
                    দাম জানতে অনুরোধ করুন
                </button>
            </form>
            <div id="prp_message" class="prp-message"></div>
        </div>
    </div>
    <?php

    return ob_get_clean();
}
add_shortcode( 'product_request_form', 'prp_form_html' );

/**
 * ৪. ফর্ম সাবমিশন হ্যান্ডলিং (AJAX)
 */
function prp_handle_form_submission() {
    if ( ! isset( $_POST['product_request_field'] ) || ! wp_verify_nonce( $_POST['product_request_field'], 'product_request_nonce' ) ) {
        wp_send_json_error( 'নিরাপত্তা ত্রুটি। দয়া করে আবার চেষ্টা করুন।' );
    }

    if ( empty( $_POST['part_name'] ) || empty( $_POST['description'] ) || empty( $_POST['vehicle_info'] ) ) {
        wp_send_json_error( 'অনুগ্রহ করে সকল আবশ্যক ফিল্ড পূরণ করুন।' );
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'product_requests';
    $image_url = '';

    // ছবি আপলোড হ্যান্ডেল করা
    if ( ! empty( $_FILES['product_image'] ) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK ) {
        if ( ! function_exists( 'wp_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }
        
        $uploadedfile = $_FILES['product_image'];
        $upload_overrides = array( 'test_form' => false );
        $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );

        if ( $movefile && ! isset( $movefile['error'] ) ) {
            $image_url = $movefile['url'];
        } else {
            wp_send_json_error( 'ছবি আপলোড করতে ব্যর্থ হয়েছে: ' . $movefile['error'] );
        }
    }

    // ডেটাবেসে তথ্য ইনসার্ট
    $wpdb->insert( 
        $table_name, 
        array( 
            'time' => current_time( 'mysql' ), 
            'product_name' => sanitize_text_field( $_POST['part_name'] ), 
            'description' => sanitize_textarea_field( $_POST['description'] ),
            'additional_info' => '', 
            'vehicle_info' => sanitize_text_field( $_POST['vehicle_info'] ),
            'image_url' => esc_url_raw( $image_url ),
        ) 
    );

    $admin_email = get_option( 'admin_email' );
    $subject = 'New Product Request Received';
    $message = "A new product request has been submitted.\n\n"
             . "Product Name: " . sanitize_text_field( $_POST['part_name'] ) . "\n"
             . "Description: " . sanitize_textarea_field( $_POST['description'] ) . "\n"
             . "Mobile Number: " . sanitize_text_field( $_POST['vehicle_info'] ) . "\n"
             . "Image URL: " . $image_url;
    wp_mail( $admin_email, $subject, $message );


    wp_send_json_success( 'আপনার অনুরোধ সফলভাবে জমা দেওয়া হয়েছে!' );
}
add_action( 'wp_ajax_prp_submit_request', 'prp_handle_form_submission' );
add_action( 'wp_ajax_nopriv_prp_submit_request', 'prp_handle_form_submission' );


/**
 * ৪.১. স্ট্যাটাস আপডেট হ্যান্ডলিং
 */
function prp_update_request_status() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'অনুমতি নেই।' );
    }

    if ( ! isset( $_POST['request_id'] ) || ! isset( $_POST['new_status'] ) || ! isset( $_POST['prp_update_nonce'] ) ) {
        wp_send_json_error( 'অবৈধ ডেটা।' );
    }

    if ( ! wp_verify_nonce( $_POST['prp_update_nonce'], 'prp_update_status_nonce' ) ) {
        wp_send_json_error( 'নিরাপত্তা ত্রুটি।' );
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'product_requests';
    $request_id = intval( $_POST['request_id'] );
    $new_status = sanitize_text_field( $_POST['new_status'] );

    $valid_statuses = array('Pending', 'Complete', 'Cancel');
    if ( ! in_array( $new_status, $valid_statuses ) ) {
        wp_send_json_error( 'অবৈধ স্ট্যাটাস মান।' );
    }

    $updated = $wpdb->update( 
        $table_name, 
        array( 'status' => $new_status ), 
        array( 'id' => $request_id ), 
        array( '%s' ), 
        array( '%d' ) 
    );

    if ( $updated !== false ) {
        wp_send_json_success( 'স্ট্যাটাস আপডেট হয়েছে।' );
    } else {
        wp_send_json_error( 'স্ট্যাটাস আপডেট ব্যর্থ হয়েছে। ডেটাবেস ত্রুটি।' );
    }
}
add_action( 'wp_ajax_prp_update_status', 'prp_update_request_status' );


/**
 * ৫. অ্যাডমিন ডিসপ্লে পেজ
 */
function prp_requests_list_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_requests';
    $results = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY time DESC", ARRAY_A );

    $statuses = array('Pending', 'Complete', 'Cancel');

    // অ্যাডমিন পেজের জন্য স্ক্রিপ্ট লোড করা
    wp_enqueue_script( 'prp-admin-script', plugins_url( 'admin-status.js', __FILE__ ), array('jquery'), '1.0.0', true );
    wp_localize_script( 'prp-admin-script', 'prp_admin_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'prp_update_status_nonce' ),
    ) );
    
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">পণ্যের অনুরোধের তালিকা</h1>
        <p>জমা দেওয়া প্রতিটি অনুরোধ একটি লিস্ট আকারে দেখা যাচ্ছে:</p>
        <div id="prp-admin-message" style="margin-bottom: 15px;"></div>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width: 5%;">ID</th>
                    <th style="width: 15%;">Product নাম</th>
                    <th style="width: 25%;">বিবরণ</th>
                    <th style="width: 15%;">মোবাইল নম্বর</th>
                    <th style="width: 10%;">ছবি</th>
                    <th style="width: 15%;">সময়</th>
                    <th style="width: 15%;">স্ট্যাটাস</th>
                </tr>
            </thead>
            <tbody>
                <?php if ( $results ) : ?>
                    <?php foreach ( $results as $request ) : ?>
                        <tr>
                            <td><?php echo esc_html( $request['id'] ); ?></td>
                            <td><strong><?php echo esc_html( $request['product_name'] ); ?></strong></td>
                            <td><?php echo esc_html( wp_trim_words( $request['description'], 10, '...' ) ); ?></td>
                            <td><?php echo esc_html( $request['vehicle_info'] ); ?></td>
                            <td>
                                <?php if ( $request['image_url'] ) : ?>
                                    <a href="<?php echo esc_url( $request['image_url'] ); ?>" target="_blank">ছবি দেখুন</a>
                                <?php else : ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html( date( 'Y-m-d H:i', strtotime( $request['time'] ) ) ); ?></td>
                            <td>
                                <select class="prp-status-select status-<?php echo sanitize_title( $request['status'] ); ?>" data-request-id="<?php echo esc_attr( $request['id'] ); ?>">
                                    <?php foreach ( $statuses as $status ) : ?>
                                        <option value="<?php echo esc_attr( $status ); ?>" <?php selected( $request['status'], $status ); ?>>
                                            <?php echo esc_html( $status ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="7">কোনো অনুরোধ পাওয়া যায়নি।</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

function prp_admin_menu() {
    add_menu_page(
        'Product Requests',
        'Product Requests',
        'manage_options',
        'product-requests',
        'prp_requests_list_page',
        'dashicons-list-view',
        6
    );
}
add_action( 'admin_menu', 'prp_admin_menu' );